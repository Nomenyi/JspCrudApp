/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nomenyi.model;

import java.util.Date;
import java.util.Calendar; 

/**
 *
 * @author angelico
 */
public class User {
    String uname, password, email;
 
    public void setUname(String uname) {
        this.uname = uname;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public String getUname() {
        return uname;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
}
