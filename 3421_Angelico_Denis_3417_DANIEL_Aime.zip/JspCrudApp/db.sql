/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  angelico
 * Created: Nov 27, 2020
 */

DROP DATABASE IF EXISTS users;
CREATE DATABASE users;
USE users;

CREATE TABLE `users` (
  `uname` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`uname`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
